const express = require('express');
const speedTest = require('speedtest-net');
const moment = require('moment');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

let results = [];
let maxStats = {
  download: 0,
  upload: 0,
  ping: Infinity
};

function runSpeedTest() {
  const test = speedTest({ acceptLicense: true, acceptGdpr: true });

  test.on('data', data => {
    const timestamp = moment().format('HH:mm:ss');
    const result = {
      time: timestamp,
      download: (data.download.bandwidth * 8 / 1e6).toFixed(2),
      upload: (data.upload.bandwidth * 8 / 1e6).toFixed(2),
      ping: data.ping.latency.toFixed(1)
    };

    results.push(result);
    if (results.length > 20) results.shift();

    maxStats.download = Math.max(maxStats.download, result.download);
    maxStats.upload = Math.max(maxStats.upload, result.upload);
    maxStats.ping = Math.min(maxStats.ping, result.ping);

    fs.writeFileSync('log.json', JSON.stringify(results, null, 2));
    console.log(`[${timestamp}] ↓ ${result.download} Mbps | ↑ ${result.upload} Mbps | ↔ ${result.ping} ms`);
  });

  test.on('error', err => console.error('Speedtest error:', err));
}

setInterval(runSpeedTest, 60 * 1000);

app.use(express.static('public'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('chart', { results, maxStats });
});

app.listen(PORT, () => {
  console.log(`Web dashboard: http://localhost:${PORT}`);
});
