# Network Speed Monitor

A real-time speed test app that works in terminal (PowerShell/CMD) and on web `localhost:3000`.

## Features

- 📈 Live graph of Download, Upload, and Ping
- 💾 Local logging (log.json)
- 🌐 Web dashboard via Chart.js + EJS
- 🖥️ CLI compatible

## Usage

```bash
npm install
npm start
```

Then open http://localhost:3000 in your browser.
